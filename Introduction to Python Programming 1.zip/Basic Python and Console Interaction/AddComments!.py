"""
enter 
first
name 
"""
first_name = input("Enter your first name: ")
"""
enter
middle
name
"""
middle_name = input("Enter your middle name: ")
"""
enter 
last 
name
"""
last_name = input("Enter your last name: ")

# put all the names together to the full name variable
full_name = first_name + " " + middle_name + " " + last_name

# print the full name
print(full_name)