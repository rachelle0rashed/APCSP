age = int(input("Enter your age: "))
age = (age + 1)
print("You will need this many candles for your birthday cake: ")
print(age)