name = "Rachelle"
lucky_num = 14
print(name)
print(lucky_num)