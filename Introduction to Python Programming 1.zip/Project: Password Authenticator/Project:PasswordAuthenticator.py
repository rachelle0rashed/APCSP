password = "password123"
user_num = 1234567899
def password_authenticator(password, user_password): 
    attempts = 0
    max_attempts = 3
    while max_attempts > attempts:
        user_password = input("Enter your password: ")
        if password == user_password:
            print("Correct password! Access granted.")
            break
        else:
            attempts += 1
            remaining_attempts = max_attempts - attempts
            if remaining_attempts > 0: 
                print("Incorrect password. You have " + str(remaining_attempts) + " attempt(s) left. Please try again.")
            else:
                print("Incorrect password. Maximmum number of attemmpts reached. Access denied. ")
                reset_answer()
                
def reset_answer():
    reset = input("Do you want to reset password? (yes/no): ")
    if reset == "yes": 
        reseting_pass()
    if reset == "no":
        print("Inncorect password. Maxium number of attempts reached. Access denied. ")
    else: 
        print("Please enter 'yes' or 'no'! ")
        reset_answer()
                
def reseting_pass():
    user_input_num = int(input("Enter phone number: "))
    if user_input_num == user_num:
        new_password = input("Enter new password must be at least 8 characters long. ")
        password = new_password
        password_authenticator(password, new_password)
    else:
        print("Sorry the number you enter isn't the same number in your account.")
        reseting_pass()
password_authenticator(password,'')