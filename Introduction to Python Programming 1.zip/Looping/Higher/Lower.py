magic_number = 3

while True:
    guess = int(input("Guess the number between 1 and 100: "))
    
    if guess > magic_number:
        print("Too high!")
        
    elif guess < magic_number:
        print("Too low!")
        
    else:
        print("Correct!")
        break