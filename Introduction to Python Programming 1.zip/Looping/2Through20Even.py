num = 0
while num < 20:
    num = num + 2
    print(num)