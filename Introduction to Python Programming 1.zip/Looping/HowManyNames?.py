num_names = int(input("How many names do you have? "))
my_string = ""
for i in range(num_names):
    i += 1
    name = input("Write name " + str(i) + ": ")
    my_string = my_string + name + " "
    
print(my_string)