answers = ""
for i in range(3):
    category = input("Enter a category: ")
    for j in range(3):
        enter = input("Enter something in that category: ")
        answers += enter + " "
    print(str(category) + ": " + str(answers))
    answers = " "