added_scores = 0
for i in range(3):
    score = int(input("Test score : "))
    added_scores =  added_scores + score

averge = added_scores / 3 
print(averge)