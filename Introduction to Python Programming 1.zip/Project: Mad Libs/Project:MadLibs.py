print("A day in New York City: a Mad Lib. Welcome! You are about to play a fun word game. I will ask you a series of nouns, pronouns, verbs, adjectives, and certain location or activity. Using those words I will create a creative story for you!" )


adjective = input("Enter an adjective: ")
noun = input("Enter an noun: ")
pronoun = input("Enter a pronoun: " )
verb = input("Enter an verb: ")
food = input("Enter an food: ")
pronoun_two = input("Enter an friend's name: ")
adjective_2 = input("Enter an adjective 2: ")
adjective_3 = input("Enter an adjective 3: ")
place = input("Enter a place: ")
game = input("Enter an game: ")

print("It was a beatiful day at New York City. There was a " + adjective + " " + noun + "." + "\n"  + " Their name was " + pronoun + " who loved to " + verb + " every day. " + pronoun +  " was hungry and ate " + food +  " with their friend " + pronoun_two + ". " + pronoun_two + " was a " + adjective_2 + " and " + adjective_3 + "\n" + " person." + " Together they went to the " + place + " and played "+ game + " and were best" + "\n" + " friends forever!" + "\n" + "THE END!")