# This program simulates a single transaction -
# either a deposit or a withdrawal - at a bank.

intial_balence = 1000
dep_with = input("Deposit or withdrawal: ")

if dep_with == "deposit":
    amount = int(input("Enter amount: "))
    final_balence = intial_balence + amount
    print("Final balance: " + str(final_balence))

elif dep_with == "withdrawal":
    amount = int(input("Enter amount: "))
    final_balence = intial_balence - amount
    if final_balence < 0:
        print("You cannot have a negative balance!")
    else:
        print("Final balance: " + str(final_balence))
else:
    print("Invalid transaction.")