reservation_name = "Shonda"

user_name = input("Name: ")

if user_name == reservation_name:
    print("Right this way!")
else:
    print("Sorry, we don't have a reservation under that name.")