age = int(input("What is your age? "))
old_enough = 18
print("Age: " + str(age))
if age >= old_enough:
    print("You are old enough to vote!")
else:
    print("You are not old enough to vote!")