age = int(input("Age: "))
citizen = input("Born in the U.S.? (Yes/No): ")
residency = int(input("Years of Residency: "))

if age >= 35 and citizen == "Yes" and residency >= 14:
    print("You are eligible to run for president!")
else:
    print("You are not eligible to run for president.")